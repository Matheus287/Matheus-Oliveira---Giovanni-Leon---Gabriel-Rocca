import javax.swing.JOptionPane;

public class ProvaRec {

	public static void main(String[] args) {

		float lado1=0, lado2=0, lado3=0;
		
		JOptionPane.showMessageDialog(null, "Programa para descobrir o tipo de um triângulo!");
		
		try {
	//Entrada de dados
		lado1=Float.parseFloat(JOptionPane.showInputDialog("Insira o primeiro lado do triângulo: "));
		lado2=Float.parseFloat(JOptionPane.showInputDialog("Insira o segundo lado do triângulo: "));
		lado3=Float.parseFloat(JOptionPane.showInputDialog("Insira o terceiro lado do triângulo: "));
		
	//Processamento de dados	
		//Descobrir se é um triângulo
		if((lado3<lado1+lado2)&(lado1<=0)|(lado2<=0)|(lado3<=0)) {
			//Descobrir se é equilátero
			if((lado1==lado2) & (lado1==lado3)) {
				JOptionPane.showMessageDialog(null, "O triângulo é equilátero.");
				}
			else {
				//Descobrir se é isósceles
				if((lado1==lado2) | (lado1==lado3) | (lado2==lado3)) { 	
				JOptionPane.showMessageDialog(null, "O triângulo é Isósceles.");
				}
				//Caso não seja nenhum é escaleno
				else {
				JOptionPane.showMessageDialog(null, "O triângulo é Escaleno.");
				}
				}
			}
		//Caso não seja um triângulo, o programa irá mostrar a seguinte mensagem:
		else {
			JOptionPane.showMessageDialog(null, "Os dados inseridos são inválidos para ser um triângulo!");
			}
		}catch(NumberFormatException e) {
			   JOptionPane.showMessageDialog(null, "Digite apenas números.");
		   }
		//Fim do processo
		JOptionPane.showMessageDialog(null, "Fim do Processo.\n Obrigado pela utilização!");
			}
		}


