import javax.swing.JOptionPane;

public class Prova {

	public static void main(String[] args) {
		
		float salmin, salatu, salatumin;
		
		salmin = Float.parseFloat(JOptionPane.showInputDialog("Insira valor do salário mínimo atual em reais: "));
		salatu = Float.parseFloat(JOptionPane.showInputDialog("Insira valor do salário atual do funcionário em reais: "));
		
		salatumin = salatu/salmin;
		
		JOptionPane.showInternalMessageDialog(null, "O funcionário ganha "+salatumin+" salários mínimos");
		

	}

}
